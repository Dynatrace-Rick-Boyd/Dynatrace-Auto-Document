To use, simply drop system profile XMLs in this directory.  Then navigate to ./index.html?p=Your%20Profile%20Name and it should populate with the appropriate styles and data.

Mad props to Mike Beemer for creating the XSL.